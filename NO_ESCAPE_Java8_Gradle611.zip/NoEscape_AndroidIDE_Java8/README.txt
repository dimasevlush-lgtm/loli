NO ESCAPE — сумісний проєкт для старого AndroidIDE.
Налаштування: Java 8, Gradle 6.1.1, Android Gradle Plugin 4.0.2.
Це лише безпечний демо-екран: він не блокує Android і закривається кнопкою Назад.

Відкрий цю папку як проєкт. Якщо AndroidIDE повідомить, що gradlew відсутній,
відкрий термінал саме в папці проєкту та виконай:
gradle wrapper --gradle-version 6.1.1

Потім:
./gradlew assembleDebug

APK після успішної збірки:
app/build/outputs/apk/debug/app-debug.apk

Потрібна Android SDK Platform 30. Якщо її немає, встанови її через SDK Manager.
