package com.example.noescape;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(32, 32, 32, 32);
        layout.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("NO ESCAPE");
        title.setTextSize(32);
        title.setTextColor(Color.RED);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("ЦЕ ЖАРТ — ДЕМО-ЕКРАН");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setGravity(Gravity.CENTER);
        layout.addView(subtitle);

        final EditText password = new EditText(this);
        password.setSingleLine(true);
        password.setHint("Введи пароль");
        password.setHintTextColor(Color.GRAY);
        password.setTextColor(Color.WHITE);
        password.setInputType(InputType.TYPE_CLASS_NUMBER |
                InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        layout.addView(password, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        Button unlock = new Button(this);
        unlock.setText("РОЗБЛОКУВАТИ");
        unlock.setOnClickListener(v -> {
            if ("1488".equals(password.getText().toString())) {
                Toast.makeText(this, "ЖАРТ! ТЕЛЕФОН ВІЛЬНИЙ 😁",
                        Toast.LENGTH_LONG).show();
                finish();
            } else password.setError("Неправильний пароль");
        });
        layout.addView(unlock);

        TextView note = new TextView(this);
        note.setText("Демо-екран. Його можна закрити кнопкою «Назад» або видалити як звичайний застосунок.");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(12);
        note.setGravity(Gravity.CENTER);
        layout.addView(note);
        setContentView(layout);
    }
}
